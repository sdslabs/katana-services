#!/bin/sh

watch ls
